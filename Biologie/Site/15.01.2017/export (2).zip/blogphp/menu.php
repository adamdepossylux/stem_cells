<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body><nav id="conteneur">
            <a style="color:black;text-decoration: none;text-align: justify;font-size: large;" href="landing_page.php">Landing Page</a>
            <a style="color:black;text-decoration: none;text-align: justify;font-size: large;" href="anmimal_regeneration.php">Regeneration in Animals</a>
            <a style="color:black;text-decoration: none;text-align: justify;font-size: large;" href="Knock_out_mice.php">Stem cells as a tool</a>
            <a style="color:black;text-decoration: none;text-align: justify;font-size: large;" href="human_regeneration.php">Regeneration among human</a>
    </nav>
</body></html>
