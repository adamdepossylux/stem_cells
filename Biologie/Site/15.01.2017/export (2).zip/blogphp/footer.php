    <footer id="bloc_footer">
    <div>
        <script type='text/javascript' src='http://www.webtutoriaux.com/services/compteur-visiteurs/index.php?client=153729'></script>
    </div>
    <div2 id="conteneur_fr">
            <a style='color:black;text-decoration: none;text-align: right;font-size: small;' href="landing_page_fr.php">fr </a>
            <a style='color:black;text-decoration: none;text-align: right;font-size: small;' href="landing_page.php">en</a>
    </div2> 
    </footer>
