<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head>
<body>    <nav id="conteneur">
            <a style='color:black;text-decoration: none;text-align: justify;font-size: large;' href="landing_page_fr.php">Page d'accueil</a>
            <a style='color:black;text-decoration: none;text-align: justify;font-size: large;' href="anmimal_regeneration_fr.php">Régénération animale</a>
            <a style='color:black;text-decoration: none;text-align: justify;font-size: large;' href="dangerous_regeneration_fr.php">Dangers de la régénération</a>
            <a style='color:black;text-decoration: none;text-align: justify;font-size: large;' href="human_regeneration_fr.php">Régénération Humaine</a>
    </nav>
</body></html>
