<!DOCTYPE html>
<html>
    <head>        
        <meta charset="utf-8" />
        <title>The codex</title>
        <link rel="stylesheet" href="style.css" />
        <link rel="stylesheet" media="votre requete ici" href="mobile.css" />
        <meta name="viewport" content="width=device-width"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <meta name="viewport" content="width=device-width, minimum-scale=0.25"/>
        <meta name="viewport" content="width=device-width, maximum-scale=5.0"/>
        <meta name="viewport" content="width=device-width, target-densitydpi=device-dpi"/>

    </head>

    <body>
	<div id="bloc_page">
		<?php include("header.php");?>
		<?php include("menu.php");?>
		<section>
		</section>
		<?php include("footer.php");?>
	</div>
    </body>
</html>
