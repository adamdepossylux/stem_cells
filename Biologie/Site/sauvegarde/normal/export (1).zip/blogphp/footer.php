    <footer id="bloc_footer">
    <div>
        <script type='text/javascript' src='http://www.webtutoriaux.com/services/compteur-visiteurs/index.php?client=153729'></script>
    </div>
    <div2 id="conteneur_fr">
            <a style='color:black;text-decoration: none;text-align: right;font-size: small;' href="anmimal_regeneration_fr.html">fr </a>
            <a style='color:black;text-decoration: none;text-align: right;font-size: small;' href="anmimal_regeneration.html">en</a>
    </div2> 
    </footer>
