    <nav id="conteneur">
            <a style='color:black;text-decoration: none;text-align: justify;font-size: large;' href="landing_page.php">Landing Page</a>
            <a style='color:black;text-decoration: none;text-align: justify;font-size: large;' href="anmimal_regeneration.php">Regeneration in Animals</a>
            <a style='color:black;text-decoration: none;text-align: justify;font-size: large;' href="dangerous_regeneration.php">Dangerous Regeneration</a>
            <a style='color:black;text-decoration: none;text-align: justify;font-size: large;' href="human_regeneration.php">Regeneration among human</a>
    </nav>
