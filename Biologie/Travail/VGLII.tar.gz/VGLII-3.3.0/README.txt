**** Virtual Genetics Lab II Instructions ****
To run VGLII, double-click the VGLII.sh script file
****

http://vgl.umb.edu
brian.white@umb.edu
January 2016